
public class Animal
{
    public  String color;//instance
    public String NumLegs;//instance
    
    public Animal(){
        
    }
    public Animal(String color, String NumLegs){
        ShowInfo(color, NumLegs);
    }
    public void ShowInfo(String color, String NumLegs){
        System.out.println(color);
        System.out.println(NumLegs);
    }
    
}
