

public class InheritanceTest
{
   public static void main(String[] args){
       //Animal Animal1 = new Animal();
       //Animal1.color = "blue";
       //Animal1.NumLegs = "4";
       
       //Animal1.ShowInfo(Animal1.color, Animal1.NumLegs);
    
       Dog Dog1 = new Dog("3","White");
       Dog1.GetDogName();
   }

}
