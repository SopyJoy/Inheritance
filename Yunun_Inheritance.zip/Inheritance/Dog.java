

public class Dog extends Animal
{
     public String DogName;
     
     public String GetDogName(){
          System.out.print(DogName);
          return DogName;
     }
     public Dog(String NumLegs, String color){
         super(NumLegs, color);
         this.DogName = "KAPATIDKO";
     }
}
